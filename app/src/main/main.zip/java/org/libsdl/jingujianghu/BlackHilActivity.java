package org.libsdl.jingujianghu;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import org.libsdl.app.SDLActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by dell on 2017/11/11.
 */

public class BlackHilActivity extends SDLActivity {

    private void requestMyPermissions() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //没有授权，编写申请权限代码
            ActivityCompat.requestPermissions(BlackHilActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        } else {
            Log.d("gtgtgt", "requestMyPermissions: 有写SD权限");
        }
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //没有授权，编写申请权限代码
            ActivityCompat.requestPermissions(BlackHilActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
        } else {
            Log.d("gtgtgt", "requestMyPermissions: 有读SD权限");
        }
    }


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        requestMyPermissions();
        String gameDataPath = "/sdcard/JinGuJiangHu/";

        //游戏存储路径
        String savePath = gameDataPath + "/save";
        File saveFile = new File(savePath);
        if(!saveFile.exists()){
            saveFile.mkdirs();
        }


        //读取字体保存到游戏目录下
        String ttfFontname = "font/font.ttf";
        String storeTTFFontFilename = this.getFilesDir()+"/"+ttfFontname;
        if(!new File(storeTTFFontFilename).exists()){
            //字体保存路径
            String fontPath = this.getFilesDir() + "/font";
            File fontFile = new File(fontPath);
            if(!fontFile.exists()){
                fontFile.mkdir();
            }
            try{
                OutputStream myOutput = new FileOutputStream(storeTTFFontFilename);
                InputStream myInput = this.getAssets().open(ttfFontname);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = myInput.read(buffer)) > 0) {
                    myOutput.write(buffer, 0, length);
                }
                myOutput.flush();
                myInput.close();
                myOutput.close();
            }catch (Exception e){
                Log.v("BlckHil", e.getMessage(), e);
            }
        }


        //把z.ini拷出来
        String zfilename = "init.txt";
        String zfilepath = gameDataPath+zfilename;
        if(!new File(zfilepath).exists()){
            try{
                OutputStream myOutput = new FileOutputStream(zfilepath);
                InputStream myInput = this.getAssets().open(zfilename);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = myInput.read(buffer)) > 0) {
                    myOutput.write(buffer, 0, length);
                }
                myOutput.flush();
                myInput.close();
                myOutput.close();
            }catch (Exception e){
                Log.v("BlckHil", e.getMessage(), e);
            }
        }


    }
}
